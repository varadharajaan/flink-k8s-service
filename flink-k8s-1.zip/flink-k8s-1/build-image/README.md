This directory is a copy of this [official flink directory](https://github.com/apache/flink/tree/release-1.9.2/flink-container/docker).  
It's only purpose is to build a flink docker image that have your job embedded in it.  
If you want to update flink, look for a newer version in flink's repo.
