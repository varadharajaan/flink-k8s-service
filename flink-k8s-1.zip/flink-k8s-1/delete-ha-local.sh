ls k8s/*-service.yaml | xargs -n 1 kubectl delete -f
ls k8s/*-ha.yaml | xargs -n 1 kubectl delete -f
kubectl delete -f k8s/namespace.yaml