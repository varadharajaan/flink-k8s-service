eval $(minikube docker-env)
./build-image.sh